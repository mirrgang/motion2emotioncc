CREATE TABLE IF NOT EXISTS BackgroundSample (
ID INTEGER primary key autoincrement,  
Participant_ID INTEGER NOT NULL,  
Sample_ID INTEGER NOT NULL, 
known INTEGER NULL, 
timeStamp DATETIME NOT NULL,
liking INTEGER NULL,
order_ Integer NOT NULL, 
suitability_embodied INTEGER NULL,
suitability_verbal INTEGER NULL,
FOREIGN KEY(Sample_ID) REFERENCES Samples(ID),  
FOREIGN KEY(Participant_ID) REFERENCES Participant(ID)
);

CREATE TABLE IF NOT EXISTS Motion (
  ID INTEGER primary key autoincrement,
  Participant_ID INTEGER NOT NULL,
  Sample_ID INTEGER NOT NULL,
  SensorData_Acc BLOB NULL,
  SensorData_Ori BLOB NULL,
  timeStamp DATETIME NOT NULL,
  Setting_ID INTEGER NULL,
FOREIGN KEY(Setting_ID) REFERENCES BackgroundSetting(ID),
FOREIGN KEY(Sample_ID) REFERENCES Sample(ID),  
FOREIGN KEY(Participant_ID) REFERENCES Participant(ID)
);

CREATE TABLE IF NOT EXISTS Participant (
  ID INTEGER primary key autoincrement,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL, 
  musicBackground TEXT NULL,
  year INTEGER NULL,
  gender TEXT NULL,
  education TEXT NULL
);

CREATE TABLE IF NOT EXISTS Sample (
  ID INTEGER primary key autoincrement,
  title TINYTEXT NULL UNIQUE,
  mp3path TEXT NULL
);

CREATE TABLE IF NOT EXISTS Emotion (
  ID INTEGER primary key autoincrement,
  joy INTEGER NULL,
  tension INTEGER NULL,
  wonder INTEGER NULL,
  sadness INTEGER NULL,
  transcendence INTEGER NULL,
  energy INTEGER NULL,
  tenderness INTEGER NULL,
  peacefulness INTEGER NULL,
  nostalgia INTEGER NULL,  
  Participant_ID INTEGER NOT NULL,
  Sample_ID INTEGER NOT NULL,
  timeStamp DATETIME NOT NULL,
  Setting_ID INTEGER NULL,
FOREIGN KEY(Setting_ID) REFERENCES BackgroundSetting(ID),
FOREIGN KEY(Sample_ID) REFERENCES Sample(ID),  
FOREIGN KEY(Participant_ID) REFERENCES Participant(ID)
);

CREATE TABLE IF NOT EXISTS Sample_has_VerbalTags (
  Participant_ID INTEGER NOT NULL,
  VerbalTag_ID INTEGER NOT NULL,
  Sample_ID INTEGER NOT NULL,
  timeStamp DATETIME NOT NULL,
  Setting_ID INTEGER NULL,
FOREIGN KEY(Setting_ID) REFERENCES BackgroundSetting(ID),
FOREIGN KEY(Sample_ID) REFERENCES Sample(ID),  
FOREIGN KEY(Participant_ID) REFERENCES Participant(ID),
FOREIGN KEY(VerbalTag_ID) REFERENCES VerbalTag(ID)
);

CREATE TABLE IF NOT EXISTS VerbalDescription (
  ID INTEGER primary key autoincrement,
  Participant_ID INTEGER NOT NULL,
  Sample_ID INTEGER NOT NULL,
  Setting_ID INTEGER NULL,
  freePlainText TEXT NULL,
  timeStamp DATETIME NOT NULL, 
FOREIGN KEY(Setting_ID) REFERENCES BackgroundSetting(ID),
FOREIGN KEY(Sample_ID) REFERENCES Sample(ID),
FOREIGN KEY(Participant_ID) REFERENCES Participant(ID)
);

CREATE TABLE IF NOT EXISTS VerbalTag (
  ID INTEGER primary key autoincrement,
  tag TEXT NULL
);

CREATE TABLE IF NOT EXISTS BackgroundSetting(
  ID INTEGER primary key autoincrement,
  mood TEXT NULL,
  location TEXT NULL,
  company TEXT NULL,
  comfortable TEXT NULL,
  speakers TEXT NULL,
  device TEXT NULL
);


