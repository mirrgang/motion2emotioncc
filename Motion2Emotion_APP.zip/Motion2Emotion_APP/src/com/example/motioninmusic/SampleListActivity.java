package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import com.example.gravitytest.R;

import dbaction.DBHandler;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * SampleListActivity is the starting point of the experiment. It lists the samples that should be processed in random order.
 * Samples already selected are marked as green and disabled, i.e. they cannot be selected more than once.
 *
 */
public class SampleListActivity extends ListActivity {

	private DBHandler dbhandler;
	private Context context;
	private ProgressDialog loadProgress;

	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		dbhandler = DBHandler.getInstance(this);
		context = this;
		// load samples from MySQL-DB if first round  
		if(dbhandler.isFirst)
		{
			SongConnect(dbhandler.getUSERNAME(), dbhandler.getUSER_PASSWORD());
			dbhandler.isFirst = false;
		}else
		{//else only initialize list with songs pre-stored in the DBHandler instance
			try{
				setListAdapter(new ArrayAdapter<String>(this, R.layout.list_layout,dbhandler.songs) {					
					/**the method returns true if all the list items can be selected **/                  
					@Override
					public boolean areAllItemsEnabled()
					{
						return false;
					}

					/**the method returns true for a particular list item position
					                 so that the list item at that  position can be selected **/
					@Override
					public boolean isEnabled(int position)
					{
						//if song has already been selected, disable it
						return !dbhandler.selected_positions[position];
					}
					
					public View getView(int position, View convertView, ViewGroup parent) {
					    TextView v = (TextView)LayoutInflater.from(parent.getContext())
					            .inflate(R.layout.list_layout, null);
					    v.setText(dbhandler.songs[position]);
					    if (!dbhandler.selected_positions[position])
					    	v.setBackgroundColor(getResources().getColor(R.color.color_white));
					    else
					    {//highlight samples already selected in previous rounds in green
					    	v.setBackgroundColor(getResources().getColor(R.color.color_light_green));
					    	v.setAlpha(0.5f);
					    }
					    return v;
					}
				});

			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * Initializes selected_positions of list in the beginning as false.
	 * Selected_positions keeps track of the samples already selected.
	 * 
	 * @param length size of list
	 */
	private void initializeSelectedPositions(int length)
	{
		dbhandler.selected_positions = new boolean[length];
		for(int j = 0; j<length;j++)
		{
			dbhandler.selected_positions[j] = false;
		}
	}

	/**
	 * SongConnection gets the list of samples from the central MySQL database and stores all titles
	 * in the local sqlite database of the device. It does not yet load the mp3 files.
	 *
	 */
	private class SongConnection extends AsyncTask<String, Void, String[]> {
		@Override
		protected String[] doInBackground(String... account) {
			Connection dbConnection = null;
			String[] songs = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String user = account[0];
				String password = account[1];
				dbConnection = DriverManager.getConnection(dbhandler.getMysqlUrl(), user, password);

				Statement statement = dbConnection.createStatement();
				statement.executeQuery("USE MusicEmotionDB");
				//get number of samples from db
				ResultSet resultN = statement.executeQuery("Select Count(*) from Sample");
				int numberOfSamples = 0;
				if(resultN.next())
				{
					numberOfSamples = resultN.getInt(1);
				}
				songs = new String[numberOfSamples];
				// get song titles from db
				ResultSet resultSet = statement.executeQuery("Select title from Sample;");
				int i=0;
				while(resultSet.next())
				{
					String mp3_title = resultSet.getString("title");
					songs[i++]=mp3_title;
				}
				initializeSelectedPositions(songs.length);
				resultSet.close();
				return songs;
			}
			catch(Exception e) {
				e.printStackTrace();
				return songs;
			}
			finally
			{
				try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		@Override
		protected void onPreExecute()
		{
			loadProgress = ProgressDialog.show(SampleListActivity.this, "Samples laden","Die Liste an Samples wird jetzt geladen.", true);             
		}; 

		@Override
		protected void onPostExecute(String[] playlist) {
			permute(playlist, new Random());
			dbhandler.songs = playlist;
			if(dbhandler.saveSongTitles(playlist))
			{
				System.out.println("Songs successfully saved on local sqlite db.");
				String[] test = dbhandler.getSongTitles();
				System.out.println(test);
			}
			try{//bind songs to list layout
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(context,R.layout.list_layout,dbhandler.songs);
				setListAdapter(adapter);  
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			loadProgress.dismiss();
		}
	}

	/**
	 * Randomly permutes the elements of the specified integer
	 * array using the specified randomizer. Slightly adapted method originally from 
	 * Bob Carpenter (http://www.java2s.com/Code/Java/Development-Class/Randomlypermutestheelementsofthespecifiedarray.htm).
	 *
	 * @param xs Array to permute.
	 * @param random Randomizer to use for permutations.
	 */
	public static void permute(String[] xs, Random random) {
		for (int i = xs.length; --i > 0; ) {
			int pos = random.nextInt(i);
			String temp = xs[pos];
			xs[pos] = xs[i];
			xs[i] = temp;
		}
	}

	public void SongConnect(String username, String password) {
		SongConnection task = new SongConnection();
		task.execute(username, password);
	}

	/**
	 * Gets the selected sample (item) and passes this information to the next Activity (MotionActivity).
	 * It also increments the counter of the DBHandler instance that keeps track of how many samples have already been selected. 
	 * 
	 * @param l list view layout element
	 * @param v view containing the list
	 * @param position selected position
	 * @param id list id
	 */
	protected void onListItemClick(ListView l, View v, int position, long id) {
		String item = (String) getListAdapter().getItem(position);
		dbhandler.turn_counter++;
		dbhandler.selected_positions[position] = true;
		Toast.makeText(this, item + " selected", Toast.LENGTH_LONG).show();
		//change View to embodied measuring
		Intent moveAct = new Intent(v.getContext(),MotionActivity.class);
		//send parameter to gravity activity
		moveAct.putExtra("song",item);
		//moveAct.putExtra("username", dbhandler.getUSERNAME());
		startActivityForResult(moveAct,1);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(resultCode==1){//set result to close APP
			setResult(1);
			finish();
		}
	}

	@Override
	public void onBackPressed() {
		//omits going back to previous activity, for reasons of comparability 
	}

}
