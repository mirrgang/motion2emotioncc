package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/

import java.io.File;
import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import org.json.JSONArray;
import org.json.JSONObject;

import com.example.gravitytest.R;

import dbaction.DBHandler;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

/**
 * SaveActivity transfers all data from the local sqlite database to the central MySQL-sever.
 * It also cleans up everything, i.e. deletes songs on local card and sqlite db.
 *
 */
public class SaveActivity extends Activity{

	private DBHandler dbHandler;
	private Button close_button;
	private ProgressDialog loadProgress;
	private Context context;
	private TextView text;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_save);
		context = this;
		this.close_button = (Button)this.findViewById(R.id.button_close);		
		text = (TextView)this.findViewById(R.id.textView_instruction);		
		dbHandler = DBHandler.getInstance(this);
		close_button.setOnClickListener(new OnClickListener(){
			//CLEAN UP
			public void onClick(View view)
			{
				// DELETE SONGS
				String[] filenames = dbHandler.getSongTitles();
				if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
					System.out.println("ANDROID FOLDER CAN BE ACCESSED");
				}
				String tmpDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).getAbsolutePath() + "/";
				for(int j=0; j<filenames.length;j++)
				{
					File file = new File(tmpDirectory+filenames[j]);
					if(file.delete())
					{
						System.out.println(filenames[j] + " has been deleted!");
					}
				}//DELETE SQLITE DB
				context.deleteDatabase(dbHandler.getDatabaseName());
				setResult(1);
				finish();
			}
		});
		SynchronizeConnect(dbHandler.getUSERNAME(),dbHandler.getUSER_PASSWORD());
	}	
		
	//####### SYNCHRONIZE DATABASES ###################################
	/**
	 * Transfer all data from local sqlite db to MySQL server. 
	 *
	 */
		private class SynchronizeDatabases extends AsyncTask<String, Void, Void> {
			@Override
			protected Void doInBackground(String... account) {
				Connection dbConnection = null;
				Integer progress = 0;
				this.publishProgress();
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					String user = account[0];
					String password = account[1];
					dbConnection = DriverManager.getConnection(dbHandler.getMysqlUrl(), user, password);

					Statement statement = dbConnection.createStatement();
					statement.executeQuery("USE MusicEmotionDB");
					
					//***************** SETTING **************************************
					//save background settings on central server
					String jsonSetting = dbHandler.getTable("BackgroundSetting");
					JSONArray jsonSetting_array = new JSONArray(jsonSetting);
					HashMap<Integer,Integer> localToCentral = new HashMap<Integer,Integer>();

					for(int i=0;i<jsonSetting_array.length();i++)
					{
						//get values from json string
						JSONObject json_data = jsonSetting_array.getJSONObject(i);
						int SettingID = json_data.getInt("ID");
						String mood = json_data.getString("mood");
						String location = json_data.getString("location");
						String company = json_data.getString("company");
						String comfort = json_data.getString("comfortable");
						String speakers = json_data.getString("speakers");
						String device = json_data.getString("device");
												
						//insert into dai-lab db
						PreparedStatement preparedStatement = dbConnection.prepareStatement("INSERT into  BackgroundSetting Values (default, ?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
						preparedStatement.setString(1, mood);
						preparedStatement.setString(2, location);
						preparedStatement.setString(3, company);
						preparedStatement.setString(4, comfort);
						preparedStatement.setString(5, speakers);
						preparedStatement.setString(6, device);						
						preparedStatement.executeUpdate();
						ResultSet rs = preparedStatement.getGeneratedKeys();
						if(rs.next())
						{
							int last_inserted_id = rs.getInt(1);
							localToCentral.put(SettingID,last_inserted_id);
						}				
					}
					
					
					
					
					//***************** MOTION ***************************************
					
					String jsonMotion = dbHandler.getTable("Motion");
					JSONArray jsonMotion_array = new JSONArray(jsonMotion);

					//########### insert json motion data into dai-lab database ##########
					for(int i=0;i<jsonMotion_array.length();i++)
					{
						//get values from json string
						JSONObject json_data = jsonMotion_array.getJSONObject(i);
						int participant_id = json_data.getInt("Participant_ID");
						int sample_id = json_data.getInt("Sample_ID");
						String acc_blob = json_data.getString("SensorData_Acc");
						String ori_blob = json_data.getString("SensorData_Ori");
						String timeStamp = json_data.getString("timeStamp");
						int setting_id = localToCentral.get(json_data.getInt("Setting_ID"));
						
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date date =  (Date) dateFormat.parse(timeStamp);
						byte[] bytes_acc = acc_blob.getBytes("ISO-8859-1");
						byte[] bytes_ori = ori_blob.getBytes("ISO-8859-1");
						
						//get participant id from dai-lab
						String username = dbHandler.getUsername(participant_id);
						ResultSet id_result = statement.executeQuery("Select ID from Participant WHERE username = '" + username + "';");
						int participant_ID = -1;
						if(id_result.next())
						{
							participant_ID = id_result.getInt("ID");
						}
						
						//get sample id from dai-lab
						String sample_name = dbHandler.getSampleName(sample_id);
						ResultSet sample_id_result = statement.executeQuery("Select ID from Sample WHERE title = '" + sample_name + "';");
						int sample_ID = -1;
						if(sample_id_result.next())
						{
							sample_ID = sample_id_result.getInt("ID");
						}
						
						//insert into dai-lab db
						PreparedStatement preparedStatement = dbConnection.prepareStatement("INSERT into  Motion Values (default, ?,?,?,?,?,?)");
						preparedStatement.setInt(1, participant_ID);
						preparedStatement.setInt(2, sample_ID);
						preparedStatement.setBytes(3, bytes_acc);
						preparedStatement.setBytes(4, bytes_ori);
						preparedStatement.setDate(5, new java.sql.Date(date.getTime()));
						preparedStatement.setInt(6, setting_id);						
						preparedStatement.executeUpdate();
					}
					
					//************ VerbalDescription ***********************************
					String jsonVerbal = dbHandler.getTable("VerbalDescription");
					JSONArray jsonVerbal_array = new JSONArray(jsonVerbal);

					//########### insert json verbal_description data into dai-lab database ##########
					for(int i=0;i<jsonVerbal_array.length();i++)
					{
						//get values from json string
						JSONObject json_data = jsonVerbal_array.getJSONObject(i);
						
						//TODO maybe reduce the redundancy for participant request
						int participant_id = json_data.getInt("Participant_ID");
						//get participant id from dai-lab
						String username = dbHandler.getUsername(participant_id);
						ResultSet id_result = statement.executeQuery("Select ID from Participant WHERE username = '" + username + "';");
						int participant_ID = -1;
						if(id_result.next())
						{
							participant_ID = id_result.getInt("ID");
						}
						
						int sample_id = json_data.getInt("Sample_ID");
						//get sample id from dai-lab
						String sample_name = dbHandler.getSampleName(sample_id);
						ResultSet sample_id_result = statement.executeQuery("Select ID from Sample WHERE title = '" + sample_name + "';");
						int sample_ID = -1;
						if(sample_id_result.next())
						{
							sample_ID = sample_id_result.getInt("ID");
						}
						
						int setting_id = localToCentral.get(json_data.getInt("Setting_ID"));
						String description = json_data.getString("freePlainText");
						String timeStamp = json_data.getString("timeStamp");						
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date date =  (Date) dateFormat.parse(timeStamp);
						
						//insert into dai-lab db
						PreparedStatement preparedStatement = dbConnection.prepareStatement("INSERT into  VerbalDescription Values (default, ?,?,?,?,?)");
						preparedStatement.setInt(1, participant_ID);
						preparedStatement.setInt(2, sample_ID);
						preparedStatement.setInt(3, setting_id);	
						preparedStatement.setString(4, description);
						preparedStatement.setDate(5, new java.sql.Date(date.getTime()));
						preparedStatement.executeUpdate();
					}


					//************ VERBALTAGS ***********************************
					String jsonVerbalTags = dbHandler.getTable("Sample_has_VerbalTags");
					JSONArray jsonVerbalTags_array = new JSONArray(jsonVerbalTags);

					//########### insert json verbal_description data into database ##########
					for(int i=0;i<jsonVerbalTags_array.length();i++)
					{
						//get values from json string
						JSONObject json_data = jsonVerbalTags_array.getJSONObject(i);
						
						//TODO maybe reduce the redundancy for participant request
						int participant_id = json_data.getInt("Participant_ID");
						//get participant id from dai-lab
						String username = dbHandler.getUsername(participant_id);
						ResultSet id_result = statement.executeQuery("Select ID from Participant WHERE username = '" + username + "';");
						int participant_ID = -1;
						if(id_result.next())
						{
							participant_ID = id_result.getInt("ID");
						}
						
						int sample_id = json_data.getInt("Sample_ID");		
						//get sample id from db
						String sample_name = dbHandler.getSampleName(sample_id);
						ResultSet sample_id_result = statement.executeQuery("Select ID from Sample WHERE title = '" + sample_name + "';");
						int sample_ID = -1;
						if(sample_id_result.next())
						{
							sample_ID = sample_id_result.getInt("ID");
						}
						
						
						int setting_id = localToCentral.get(json_data.getInt("Setting_ID"));
						String timeStamp = json_data.getString("timeStamp");						
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date date =  (Date) dateFormat.parse(timeStamp);
						
						int verbalTag_ID = json_data.getInt("VerbalTag_ID");
						//get name of tag
						String tag_name = dbHandler.getTagName(verbalTag_ID);
						int verbalTagID = -1;
						PreparedStatement preparedSelect = dbConnection.prepareStatement("Select ID from VerbalTag WHERE tag = ? ;");
						preparedSelect.setString(1, tag_name);
						ResultSet tag_result = preparedSelect.executeQuery();
						if(tag_result.next())
						{
							verbalTagID = tag_result.getInt("ID");
						}
						
						//insert into db
						PreparedStatement preparedStatement = dbConnection.prepareStatement("INSERT into  Sample_has_VerbalTags Values (?,?,?,?,?)");
						preparedStatement.setInt(1, participant_ID);
						preparedStatement.setInt(2, verbalTagID);
						preparedStatement.setInt(3, sample_ID);
						preparedStatement.setDate(4, new java.sql.Date(date.getTime()));
						preparedStatement.setInt(5, setting_id);	
						preparedStatement.executeUpdate();
					}
					
					
					//************ EMOTION ***********************************
					String jsonEmotion = dbHandler.getTable("Emotion");
					JSONArray jsonEmotion_array = new JSONArray(jsonEmotion);

					//########### insert json emotion data into dai-lab database ##########
					for(int i=0;i<jsonEmotion_array.length();i++)
					{
						//get values from json string
						JSONObject json_data = jsonEmotion_array.getJSONObject(i);
						int joy = json_data.getInt("joy");
						int tension = json_data.getInt("tension");
						int wonder = json_data.getInt("wonder");
						int sadness = json_data.getInt("sadness");
						int transcendence = json_data.getInt("transcendence");
						int energy = json_data.getInt("energy");
						int tenderness = json_data.getInt("tenderness");
						int peacefulness = json_data.getInt("peacefulness");
						int nostalgia = json_data.getInt("nostalgia");						
						int participant_id = json_data.getInt("Participant_ID");
						//get participant id from dai-lab
						String username = dbHandler.getUsername(participant_id);
						ResultSet id_result = statement.executeQuery("Select ID from Participant WHERE username = '" + username + "';");
						int participant_ID = -1;
						if(id_result.next())
						{
							participant_ID = id_result.getInt("ID");
						}
						int sample_id = json_data.getInt("Sample_ID");
						//get sample id from dai-lab
						String sample_name = dbHandler.getSampleName(sample_id);
						ResultSet sample_id_result = statement.executeQuery("Select ID from Sample WHERE title = '" + sample_name + "';");
						int sample_ID = -1;
						if(sample_id_result.next())
						{
							sample_ID = sample_id_result.getInt("ID");
						}
						
						int setting_id = localToCentral.get(json_data.getInt("Setting_ID"));
						String timeStamp = json_data.getString("timeStamp");						
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date date =  (Date) dateFormat.parse(timeStamp);
					
						//insert into dai-lab db
						PreparedStatement preparedStatement = dbConnection.prepareStatement("INSERT into  Emotion Values (default, ?,?,?,?,?, ?, ?, ?, ?, ?, ?, ?, ?)");
						preparedStatement.setInt(1, joy);
						preparedStatement.setInt(2, tension);
						preparedStatement.setInt(3, wonder);
						preparedStatement.setInt(4, sadness);
						preparedStatement.setInt(5, transcendence);
						preparedStatement.setInt(6, energy);
						preparedStatement.setInt(7, tenderness);
						preparedStatement.setInt(8, peacefulness);
						preparedStatement.setInt(9, nostalgia);
						preparedStatement.setInt(10, participant_ID);
						preparedStatement.setInt(11, sample_ID);
						preparedStatement.setDate(12, new java.sql.Date(date.getTime()));
						preparedStatement.setInt(13, setting_id);	
						preparedStatement.executeUpdate();
					}
					
					//************ BackgroundSample ***********************************
					String jsonBackgroundSample = dbHandler.getTable("BackgroundSample");
					JSONArray jsonback_array = new JSONArray(jsonBackgroundSample);

					//########### insert json Background Sample data into dai-lab database ##########
					for(int i=0;i<jsonback_array.length();i++)
					{
						//get values from json string
						JSONObject json_data = jsonback_array.getJSONObject(i);
						int like = json_data.getInt("liking");
						int known = json_data.getInt("known");
						int order_position = json_data.getInt("order_");
						int suit_embodied = json_data.getInt("suitability_embodied");
						int suit_verbal = json_data.getInt("suitability_verbal");
						int participant_id = json_data.getInt("Participant_ID");
						//get participant id from dai-lab
						String username = dbHandler.getUsername(participant_id);
						ResultSet id_result = statement.executeQuery("Select ID from Participant WHERE username = '" + username + "';");
						int participant_ID = -1;
						if(id_result.next())
						{
							participant_ID = id_result.getInt("ID");
						}
						int sample_id = json_data.getInt("Sample_ID");	
						//get sample id from dai-lab
						String sample_name = dbHandler.getSampleName(sample_id);
						ResultSet sample_id_result = statement.executeQuery("Select ID from Sample WHERE title = '" + sample_name + "';");
						int sample_ID = -1;
						if(sample_id_result.next())
						{
							sample_ID = sample_id_result.getInt("ID");
						}
						
						String timeStamp = json_data.getString("timeStamp");						
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date date =  (Date) dateFormat.parse(timeStamp);
					
						//insert into dai-lab db
						PreparedStatement preparedStatement = dbConnection.prepareStatement("INSERT into  BackgroundSample Values (default, ?,?,?,?,?, ?, ?,?)");
						preparedStatement.setInt(1, participant_ID);
						preparedStatement.setInt(2, sample_ID);
						preparedStatement.setInt(3, known);
						preparedStatement.setDate(4, new java.sql.Date(date.getTime()));
						preparedStatement.setInt(5, suit_embodied);
						preparedStatement.setInt(6, suit_verbal);
						preparedStatement.setInt(7, like);		
						preparedStatement.setInt(8, order_position);
						preparedStatement.executeUpdate();
					}
					
					return null;
				}
				catch(Exception e) {
					e.printStackTrace();
					return null;
				}
				finally
				{
					try {
						dbConnection.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}

			@Override
			protected void onPreExecute()
			{
				loadProgress = new ProgressDialog(context);
				loadProgress.setTitle("Daten übertragen");
				loadProgress.setMessage("Die Daten werden nun an den zentralen Server übertragen. Bitte schließen Sie die Anwendung noch nicht.");
				loadProgress.show();
			}; 
			
		    protected void onProgressUpdate(String... progress) {        
		        loadProgress.setProgress(Integer.parseInt(progress[0]));
		    }

			
			@Override
			protected void onPostExecute(Void rien) {
				loadProgress.dismiss();
				close_button.setEnabled(true);
				text.setText("Vielen Dank für Ihre Teilnahme! Die Daten wurden erfolgreich übertragen. Sie können die Anwendung nun schließen.");
			}
		}

		public void SynchronizeConnect(String username, String password) {
			SynchronizeDatabases task = new SynchronizeDatabases();
			task.execute(username, password);
		}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.save, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	@Override
	public void onBackPressed() {
		//omits going back to previous activity, for reasons of comparability
	}
}
