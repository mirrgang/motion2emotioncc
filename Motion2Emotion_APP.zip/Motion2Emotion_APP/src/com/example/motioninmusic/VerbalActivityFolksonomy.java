package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.LinkedList;

import com.example.gravitytest.R;

import dbaction.DBHandler;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * VerbalActivityFolksonomy provides a semi-open verbal description of the music.
 * The song is annotated by clicking on tags from a folksonomy. 
 * This clicking-event creates a new #-tag that is listed at the bottom of the view. 
 * #-tags might be removed again be clicking on them. 
 * The folksonomy is loaded from the central MySQL database and consists of user generated tags.
 * Tags can be added to the folksonomy by entering a tag in the new_tag field and clicking add_tag_button.
 * The newly generated tags are added to the MySQL database directly after leaving the view.
 * 
 * The corresponding layout view is activity_verbal_activity_folksonomy.
 * 
 * @author Melanie Irrgang
 *
 */
public class VerbalActivityFolksonomy extends Activity {

	private TextView song_title;
	private Button add_tag_button;
	private Button save_button;
	private PredicateLayout folksonomy;//folksonomy layout
	private EditText new_tag;//add tag text field
	private HashSet<String> folksonomy_set;//string values of folksonomy tags
	private HashSet<String> tag_set;
	private PredicateLayout tags;
	private ProgressDialog loadProgress;
	private DBHandler dbHandler;
	private LinkedList<String> userCreatedFolksonomyTags;//keeps track of newly added tags
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		try{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_verbal_activity_folksonomy);

			// get passed intent 
			Intent intent = getIntent();
			// get song value from intent
			String song = intent.getStringExtra("song");
			tag_set = new HashSet<String>();
			folksonomy_set = new HashSet<String>();
			userCreatedFolksonomyTags = new LinkedList<String>();
			dbHandler = DBHandler.getInstance(this);
			this.song_title = (TextView)findViewById(R.id.title_song_verbal);
			//set song title
			this.song_title.setText(song);
			//#get GUI elements
			this.tags = (PredicateLayout)findViewById(R.id.verbal_tags);
			this.folksonomy = (PredicateLayout)findViewById(R.id.folksonomy);
			//initialize folksonomy, get tags from MySQL server
			FolksonomyConnect(dbHandler.getUSERNAME(), dbHandler.getUSER_PASSWORD());
			this.new_tag = (EditText)findViewById(R.id.addTag_Text);
			this.add_tag_button = (Button)findViewById(R.id.button_addTag);
			this.add_tag_button.setOnClickListener(this.onAddTagClick());
			this.save_button = (Button)findViewById(R.id.save_button_verbal);


			this.save_button.setOnClickListener(new OnClickListener(){
				public void onClick(View view)
				{
					Context context = view.getContext();
					//##### REMEMBER TAGS ###########################
					int numberOfTags = tags.getChildCount();
					String[] songTags = new String[numberOfTags];
					//get all tags values and save them in songTags
					for(int i=0; i<numberOfTags;i++)
					{
					  TextView currentTag = (TextView)tags.getChildAt(i);
					  String tagValue = currentTag.getText().toString();
					  tagValue = tagValue.replace("#", ""); //get rid of hash-tag
					  songTags[i] = tagValue;
					}
					//save tags to database
					dbHandler.saveVerbalTags(songTags, song_title.getText().toString());
					//save new user created tags in folksonomy on dai-lab server
					SaveUserCreatedTags(dbHandler.getUSERNAME(), dbHandler.getUSER_PASSWORD());
					//################################################
					Intent emotionActivity = new Intent(context,EmotionActivity.class);
					//send song as parameter to verbal activity
					emotionActivity.putExtra("song",song_title.getText());//hand over song title
					startActivityForResult(emotionActivity,1);
				}
			});
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    if(resultCode==1){//set result to close APP
	    	setResult(1);
	        finish();
	    }
	}
	
	/**
	 * Initializes the folksonomy by creating a clickable TextView for each tag from the MySQL database.
	 * @param folksonomy_parts tags that go in the folksonomy
	 */
	private void initializeFolksonomy(String[] folksonomy_parts){
		for(String tag : folksonomy_parts)
		{
			this.folksonomy.addView(this.createNewTextView(tag));
			this.folksonomy_set.add(tag);
		}
	}

	@Override
	public void onBackPressed() {
		//omits going back to previous activity, for reasons of comparability
	}

	/**
	 * Listener for the 'add-tag'-button. The listener checks if user added tag already is in the folksonomy. 
	 * If not it adds a new tag to the folksonomy.
	 * @return onAddTagClick-Listener
	 */
	private OnClickListener onAddTagClick() {
		return new OnClickListener() {
			@Override
			public void onClick(View v) {
				String user_tag = new_tag.getText().toString();
				if(!folksonomy_set.contains(user_tag))
				{
					folksonomy.addView(createNewTextView(user_tag));
					folksonomy_set.add(user_tag);
					userCreatedFolksonomyTags.add(user_tag);//remember tag for insert into MySQL db
					addTag(user_tag);
				}else
					Toast.makeText(v.getContext(), "Tag ist bereits in Liste.", Toast.LENGTH_LONG).show();
			}
		};
	}

	/**
	 * Creates a new tag text view element. This element also features a listener 
	 * adding a #tag if it is clicked in the folksonomy.
	 * 
	 * @param text text of tag
	 * @return tag text view for folksonomy
	 */
	private TextView createNewTextView(String text) {
		final LayoutParams lparams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		final TextView textView = new TextView(this);
		textView.setPadding(6, 6, 6, 6);
		textView.setLayoutParams(lparams);
		textView.setText(text);
		textView.setTextColor(Color.parseColor("#68228B"));//
		textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
		textView.setClickable(true);
		textView.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				TextView tag_view = (TextView)view;
				addTag((String)tag_view.getText());
			}
		});
		return textView;
	}

	/**
	 * Adds a #-tag to the list of annotations for the song. 
	 * This text view #-tag also listens to clicks and will be removed when clicked upon.
	 *  
	 * @param tag text of #-tag
	 */
	private void addTag(String tag)
	{
		
		final LayoutParams lparams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		final TextView textView = new TextView(this);
		textView.setPadding(6, 6, 6, 6);
		textView.setLayoutParams(lparams);
		textView.setText("#"+tag);
		if(!tag_set.contains(textView.getText().toString()))
		{
			textView.setTextColor(Color.parseColor("#458B00"));//light, more yellow khaki green
			textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
			textView.setClickable(true);
			textView.setOnClickListener(new OnClickListener() {
				public void onClick(View view) {
					tags.removeView(view);
					TextView currentView = (TextView)view;
					tag_set.remove(currentView.getText().toString());
				}
			});
			tag_set.add("#"+tag);
			tags.addView(textView);   
		}else
			Toast.makeText(this, "Tag ist bereits gewählt.", Toast.LENGTH_LONG).show();
	}
	
	//####### GET FOLKSONOMY TAGS from DB ###################################
	/**
	 * Loads tags from the MySQl database and initializes folksonomy view.
	 * 
	 */
	private class FolksonomyConnection extends AsyncTask<String, Void, String[]> {
		@Override
		protected String[] doInBackground(String... account) {
			Connection dbConnection = null;
			String[] tags = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String user = account[0];
				String password = account[1];
				dbConnection = DriverManager.getConnection(dbHandler.getMysqlUrl(), user, password);

				Statement statement = dbConnection.createStatement();
				statement.executeQuery("USE MusicEmotionDB");
				//get number of tags from db
				ResultSet resultN = statement.executeQuery("Select Count(ID) from VerbalTag");
				int numberOfSamples = 0;
				if(resultN.next())
				{
					numberOfSamples = resultN.getInt(1);
				}
				tags = new String[numberOfSamples];
				// get tags from db
				ResultSet resultSet = statement.executeQuery("Select tag from VerbalTag;");
				int i=0;
				while(resultSet.next())
				{
					String currentTag = resultSet.getString("tag");
					tags[i++]=currentTag;
				}
				resultSet.close();
				return tags;
			}
			catch(Exception e) {
				e.printStackTrace();
				return tags;
			}
			finally
			{
				try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		@Override
		protected void onPreExecute()
		{
			loadProgress = ProgressDialog.show(VerbalActivityFolksonomy.this, "Tags laden","Liste an Schlagworten wird geladen.", true);             
		}; 
		
		@Override
		protected void onPostExecute(String[] tags) {
			//initialize folksonomy
			initializeFolksonomy(tags);
			loadProgress.dismiss();
		}
	}

	public void FolksonomyConnect(String username, String password) {
		FolksonomyConnection task = new FolksonomyConnection();
		task.execute(username, password);
	}
	
	//####### INSERT FOLKSONOMY TAGS into DB ###################################
	/**
	 * Inserts new user generated tags into MySQL database. 
	 *
	 */
		private class FolksonomyInsert extends AsyncTask<String, Void, Void> {
			@Override
			protected Void doInBackground(String... account) {
				Connection dbConnection = null;
				String[] tags = null;
				try {
					Class.forName("com.mysql.jdbc.Driver");
					String user = account[0];
					String password = account[1];
					dbConnection = DriverManager.getConnection(dbHandler.getMysqlUrl(), user, password);
					PreparedStatement preparedStatement = null;
					//insert tags into db
					for (final String tag : userCreatedFolksonomyTags) {
						preparedStatement = dbConnection.prepareStatement("INSERT into  VerbalTag Values (default, ?)");
						preparedStatement.setString(1, tag);
						preparedStatement.executeUpdate();
					}			
					return null;
				}
				catch(Exception e) {
					e.printStackTrace();
					return null;
				}
				finally
				{
					try {
						dbConnection.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}

		private void SaveUserCreatedTags(String username, String password) {
			FolksonomyInsert task = new FolksonomyInsert();
			task.execute(username, password);
		}
}
