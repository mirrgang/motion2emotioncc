package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/

import com.example.gravitytest.R;

import dbaction.DBHandler;
import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

/**
 * SettingActivity captures background information about how the experiment has been conducted which
 * is particularly important in the field. But it also assesses the mood participants were in during the experiment
 *  and how comfortable they felt in their surroundings.
 *  
 *  The corresponding Layout View is activity_setting.
 *
 */

public class SettingActivity extends ActionBarActivity implements OnItemSelectedListener, OnClickListener{

	private String mood;//the mood the participant has been in during the experiment
	//open text fields
	private EditText location;//where the experiment had been conducted 
	private EditText company;//whether participants had been alone or not
	private EditText comfort;//how comfortable the surroundings have been
	private EditText speakers;//using speakers, headphone (with or without cable)
	private EditText device;//on which device the experiment has been conducted with
	private Button exit_button;//finish experiment
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setting);
		
		location = (EditText)findViewById(R.id.editText_location);
		company = (EditText)findViewById(R.id.editText_company);
		comfort = (EditText)findViewById(R.id.editText_comfortable);
		speakers = (EditText)findViewById(R.id.editText_speakers);
		device = (EditText) findViewById(R.id.editText_device);
		exit_button = (Button)findViewById(R.id.button_exit);
		exit_button.setOnClickListener(this);
		
		Spinner spinner = (Spinner) findViewById(R.id.spinner_mood);
		// Create an ArrayAdapter using the string array and a default spinner layout
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
		        R.array.moods, android.R.layout.simple_spinner_item);
		// Specify the layout to use when the list of choices appears
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// Apply the adapter to the spinner
		spinner.setAdapter(adapter);
		spinner.setOnItemSelectedListener(this);
	}
	

	@Override
	/**
	 * Save everything and redirect participant to SaveActivity 
	 * where all data is being transferred from the local sqlite db to the central MySQL database.
	 */
	public void onClick(View v) {
		//save setting in database
		DBHandler dbHandler = DBHandler.getInstance(this);
		dbHandler.saveSetting(mood, speakers.getText().toString(), comfort.getText().toString(), company.getText().toString(), location.getText().toString(),device.getText().toString());
		//redirect user to SaveActivity	
		Intent saveActivity = new Intent(this,SaveActivity.class);
		this.startActivityForResult(saveActivity,1);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    if(resultCode==1){//set result to close APP
	    	setResult(1);
	        finish();
	    }
	}
	
	/**
	 * Notices if mood has been selected and remembers it.
	 */
	public void onItemSelected(AdapterView<?> parent, View view, 
            int pos, long id) {
        // remember selected mood
        this.mood = (String) parent.getItemAtPosition(pos);
    }

    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }
    
    @Override
	public void onBackPressed() {
	    //SUPPRESSES GOING BACK TO LAST ACTIVITY
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.setting, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
