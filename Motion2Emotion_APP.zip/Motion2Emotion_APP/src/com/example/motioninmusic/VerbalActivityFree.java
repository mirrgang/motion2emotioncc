package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.gravitytest.R;

import dbaction.DBHandler;

/**
 * VerbalActivityFree features an open verbal description. 
 * The open text is saved to local sqlite database when user clicks the 'next'-button.
 * 
 * The corresponding layout view is activity_verbal.
 *
 */
public class VerbalActivityFree extends Activity {

	private TextView song_title;
	private Button save_button;
	private EditText free_text;//free text field

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		try{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_verbal);

			// get passed intent 
			Intent intent = getIntent();
			// get song value from intent
			String song = intent.getStringExtra("song");
			this.song_title = (TextView)findViewById(R.id.title_song_verbal);
			//set song title
			this.song_title.setText(song);
			//#get GUI elements
			this.free_text = (EditText)findViewById(R.id.free_text_input);
			this.save_button = (Button)findViewById(R.id.next_button_verbal);
			
			this.save_button.setOnClickListener(new OnClickListener(){
				public void onClick(View view)
				{
					Context context = view.getContext();
					//save text to db if not empty
					String userText = free_text.getText().toString();
					if (userText!=null)
					{
						DBHandler dbHandler = DBHandler.getInstance(context);
						dbHandler.saveFreeText(userText, song_title.getText().toString());
					}
					Intent verbalActivityFolksonomy = new Intent(context,VerbalActivityFolksonomy.class);
					//send song as parameter to verbal activity folksonomy
					verbalActivityFolksonomy.putExtra("song",song_title.getText());//hand over song title
					startActivityForResult(verbalActivityFolksonomy,1);
				}
			});
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    if(resultCode==1){//set result to close APP
	    	setResult(1);
	        finish();
	    }
	}

	@Override
	public void onBackPressed() {
		//omits going back to previous activity, for reasons of comparability 
	}	
}
