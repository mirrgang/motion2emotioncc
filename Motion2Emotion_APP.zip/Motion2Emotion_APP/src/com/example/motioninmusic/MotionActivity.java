package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/

import dbaction.DBHandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;

import com.example.gravitytest.R;

import dbaction.ZipHelper;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

/**
 * MotionActivity captures accelerometer and orientation data from the device in synchrony to the selected song being played.
 * The participant is obliged to a test listening phase 
 * that one might interrupt by pressing pause or stop in case the piece is already known very well.
 * The sensor data is stored on the device's local sqlite db by DBHandler.
 * 
 * The corresponding view is activity_motion.
 *
 */
public class MotionActivity extends Activity implements SensorEventListener, OnCompletionListener{

	Sensor accelerometer_sensor;
	SensorManager manager_acc;

	Context context;

	Sensor orientation_sensor;
	SensorManager manager_orient;

	private TextView song_title;
	private Button play_button;
	private Button record_button;
	private Button stop_button;
	private TextView help_text_link;
	private TextView now_recording;
	private TextView test_rehearsal;
	//	Button next_button;
	private boolean isPaused;
	private boolean isRecording;
	private MediaPlayer player;
	private ProgressDialog loadProgress;

	//## FILES TO SAVE MOTION IN ############
	private FileWriter csvWriter_Acc;
	private FileWriter csvWriter_Ori;

	private String csv_filename;
	private File zipFile_acc;
	private File csvFile_acc;

	private File zipFile_ori;
	private File csvFile_ori;
	//######################################
	private String tmpDirectory;
	private DBHandler dbHandler;//connection to local sqlite db

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_motion);
		this.dbHandler = DBHandler.getInstance(this);
		//#set up sensor capturing
		manager_acc = (SensorManager)getSystemService(SENSOR_SERVICE);
		accelerometer_sensor = manager_acc.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		manager_acc.registerListener(this, accelerometer_sensor, SensorManager.SENSOR_DELAY_NORMAL);

		manager_orient = (SensorManager)getSystemService(SENSOR_SERVICE);
		orientation_sensor = manager_orient.getDefaultSensor(Sensor.TYPE_ORIENTATION);
		manager_orient.registerListener(new SensorEventListener(){
			public void onAccuracyChanged(Sensor arg0, int arg1) {
			}

			@Override
			public void onSensorChanged(SensorEvent event) {
				if(isRecording)
				{
					try {
						csvWriter_Ori.append(Float.toString(event.values[0]));
						csvWriter_Ori.append(',');
						csvWriter_Ori.append(Float.toString(event.values[1]));
						csvWriter_Ori.append(',');
						csvWriter_Ori.append(Float.toString(event.values[2]));
						csvWriter_Ori.append('\n');
					} catch (IOException e) {
						System.err.println("Orientation Sensor Movements could not be saved.");
						e.printStackTrace();
					}
				}	
			}
		}, orientation_sensor, SensorManager.SENSOR_DELAY_NORMAL);


		context = this;
		//#set up player to play back music
		player = new MediaPlayer();
		player.setOnCompletionListener(this);
		//#set up GUI
		// get passed intent 
		Intent intent = getIntent();
		// get song value from intent
		String song = intent.getStringExtra("song");
		song_title = (TextView)findViewById(R.id.text_title);
		//set song title
		song_title.setText(song);
		this.now_recording = (TextView)findViewById(R.id.text_now_recording);
		try{
			this.GetSong(song, dbHandler.getUSERNAME(), dbHandler.getUSER_PASSWORD());
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		//set song MediaPlayer should play back

		//define filename
		this.csv_filename = (String)song_title.getText();
		//delete file extension
		this.csv_filename = this.csv_filename.substring(0, this.csv_filename.lastIndexOf("."));
		//create csv file folder on sdcard
		// create a File object for the parent directory
		//		tmpDirectory = context.getFilesDir().getPath().toString()+"/";
		if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			System.out.println("ANDROID FOLDER CAN BE ACCESSED");
		}
		tmpDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).getAbsolutePath() + "/";
		// create a File object for the output file
		zipFile_acc = new File(tmpDirectory+this.csv_filename+".zip");		
		zipFile_ori = new File(tmpDirectory+this.csv_filename+"_o.zip");

		play_button = (Button)findViewById(R.id.play_button);
		record_button = (Button)findViewById(R.id.record_button);
		record_button.setEnabled(false);
		stop_button  = (Button)findViewById(R.id.stop_button);
		this.help_text_link = (TextView)findViewById(R.id.text_help_recording);
		this.test_rehearsal = (TextView)findViewById(R.id.test_description);

		this.isRecording = false;
		this.isPaused = false;
		//play back audio sample when button is pressed
		play_button.setOnClickListener(new OnClickListener(){
			public void onClick(View view){
				//user wants to pause the playback
				if(play_button.getText().toString().equals("pause"))
				{
					player.pause();
					isPaused = true;
					play_button.setText("abspielen");
					play_button.setCompoundDrawablesWithIntrinsicBounds( R.drawable.player_play, 0, 0, 0);
					record_button.setEnabled(true);
				}
				else{//user wants to play the audio
					record_button.setEnabled(false);	
					if(!isPaused)
					{
						try {
							player.prepare();
							player.seekTo(0);
							player.start();		
							play_button.setText("pause");
							play_button.setCompoundDrawablesWithIntrinsicBounds( R.drawable.noatunpause, 0, 0, 0);
							stop_button.setEnabled(true);
						} catch (IllegalStateException | IOException e) {
							e.printStackTrace();
						}		
						isPaused = true;
					}else
					{
						player.start();		
						play_button.setText("pause");
						play_button.setCompoundDrawablesWithIntrinsicBounds( R.drawable.noatunpause, 0, 0, 0);
						stop_button.setEnabled(true);
						isPaused=false;
					}
				}
			}
		});
		stop_button.setEnabled(false);
		stop_button.setOnClickListener(new OnClickListener(){
			public void onClick(View view){
				player.stop();
				stop_button.setEnabled(false);
				play_button.setText("abspielen");
				play_button.setCompoundDrawablesWithIntrinsicBounds( R.drawable.player_play, 0, 0, 0);
				isPaused=false;
				record_button.setEnabled(true);	
			}
		});

		//play back audio sample on button press and record movement captured by sensors
		record_button.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				try {
					//make everything invisible except for instructions
					play_button.setVisibility(View.INVISIBLE);
					record_button.setVisibility(View.INVISIBLE);
					stop_button.setVisibility(View.INVISIBLE);
					song_title.setVisibility(View.INVISIBLE);
					record_button.setVisibility(View.INVISIBLE);
					help_text_link.setVisibility(View.INVISIBLE);
					now_recording.setVisibility(View.VISIBLE);
					test_rehearsal.setVisibility(View.INVISIBLE);
					//prepare file writer that writes sensor data to CSV file
					//create new CSV file with song title name
					csvFile_acc = new File(tmpDirectory+csv_filename+".csv");
					csvFile_ori = new File(tmpDirectory+csv_filename+"_o.csv");
					//if file already exists, it is recreated
					if(!csvFile_acc.createNewFile())
					{						
						csvFile_acc.delete();
						csvFile_acc.createNewFile();
					}
					csvWriter_Acc = new FileWriter(csvFile_acc);
					// and for the orientation sensor as well
					if(!csvFile_ori.createNewFile())
					{						
						csvFile_ori.delete();
						csvFile_ori.createNewFile();
					}
					csvWriter_Ori = new FileWriter(csvFile_ori);

					//disable buttons during play back
					play_button.setEnabled(false);
					record_button.setEnabled(false);
					stop_button.setEnabled(false);
					//if player is only paused, stop it before it is being played again
					if(isPaused)
					{
						player.stop();
					}
					//prepare player

					player.prepare();
					player.seekTo(0);
					player.start();
					isRecording = true;
				} catch (Exception e) {
					e.printStackTrace();
				}                
			}
		});
	}

/**
 * Sends request for mp3 file of current song title and saves it in a tmp folder of the local device.
 * Attaches mp3-file to player for playback.  
 *
 */
	private class LoadSong extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			Connection dbConnection = null;
			String song = params[0];
			File audio = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				dbConnection = DriverManager.getConnection(dbHandler.getMysqlUrl(), params[1], params[2]);
				// System.out.println("Database connection success"); 

				Statement statement = dbConnection.createStatement();
				statement.executeQuery("USE MusicEmotionDB");
				//get number of samples from db
				ResultSet audioResult = statement.executeQuery("Select mp3 from Sample where title='"+song+"';");
				if(audioResult.next())
				{
					try {
						Blob blob = audioResult.getBlob("mp3");
						// materialize BLOB onto client
						byte[] audioBytes = blob.getBytes(1, (int) blob.length());

						OutputStream os = new FileOutputStream(tmpDirectory +  song);
						os.write(audioBytes);
						os.flush();
						os.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					audioResult.close();				
				}

				return null;
			}
			catch(Exception e) {
				e.printStackTrace();
				return null;
			}
			finally
			{
				try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		@Override
		protected void onPreExecute()
		{
			loadProgress = ProgressDialog.show(MotionActivity.this, "Song laden","Titel wird geladen", true);             
		}; 

		protected void onPostExecute(Void result) {
			try {
				//set song of mediaplayer
				player.setDataSource(tmpDirectory+song_title.getText().toString());
				loadProgress.dismiss();
			} catch (IllegalArgumentException e1) {
				e1.printStackTrace();
			} catch (IllegalStateException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}		
		}
	}

	/**
	 * Calls LoadSong to get selected song from the central MySQL-Server.
	 * 
	 * @param song title to be requested
	 * @param username name of user account
	 * @param password password of user account
	 */
	public void GetSong(String song, String username, String password) {
		//check if song exists already in assets
		try {
			if(!Arrays.asList(getResources().getAssets().list("")).contains(song))
			{
				LoadSong task = new LoadSong();
				task.execute(song, username, password);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	@Override
	public void onBackPressed() {
		//omits going back to previous activity, for reasons of comparability
	}

	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {

	}

	/**
	 * onSensorChanged captures acceleration of device in csv file.
	 */
	public void onSensorChanged(SensorEvent event) {
		if(this.isRecording)
		{
			try {
				csvWriter_Acc.append(Float.toString(event.values[0]));
				csvWriter_Acc.append(',');
				csvWriter_Acc.append(Float.toString(event.values[1]));
				csvWriter_Acc.append(',');
				csvWriter_Acc.append(Float.toString(event.values[2]));
				csvWriter_Acc.append('\n');
			} catch (IOException e) {
				System.err.println("Sensor Movements could not be saved.");
				e.printStackTrace();
			}
		}	
	}

/**
 * OnCompletion is called when the player completed playing, 
 * i.e. 1. when the test listening phase is completed or 2. when the motion capturing is completed,
 * For 1. the buttons from phase 1 are disabled and the player is stopped in order to prepare for phase 2.
 * For 2. the captured sensor data csvs (also see onSensorChanged) are zipped and saved on local sqlite db.
 * The participant is redirected to the next Activity.
 * 
 * @param mp MediaPlayer which state must be handled for repeated playback
 */
	public void onCompletion(MediaPlayer mp) {

		//if user has been recording already while listening to the play back of the player...
		if(this.isRecording)
		{
			//stop capturing of sensor and move on to next activity, verbal description of the audio sample
			this.isRecording = false;
			//save sensor data in csv file and zip it
			try {
				csvWriter_Acc.flush();
				csvWriter_Acc.close();				
				ZipHelper.fileToZip(csvFile_acc, zipFile_acc, 9);

				csvWriter_Ori.flush();
				csvWriter_Ori.close();				
				ZipHelper.fileToZip(csvFile_ori, zipFile_ori, 9);
				//DELETE uncompressed tmp CSV file
				if(csvFile_acc.delete()){
					System.out.println(csvFile_acc.getName() + " is deleted!");
				}else{
					System.out.println("Uncompressed Accelerometer CSV file could not be deleted.");
				}
				if(csvFile_ori.delete()){
					System.out.println(csvFile_ori.getName() + " is deleted!");
				}else{
					System.out.println("Uncompressed Orientation CSV file could not be deleted.");
				}
			} catch (IOException e) {
				System.err.println("Problem when finally saving data to CSV file.");
				e.printStackTrace();
			} catch (Exception e) {
				System.err.println("Problem when zipping CSV file.");
				e.printStackTrace();
			}			
			this.dbHandler.saveZippedCSV((String)song_title.getText(),zipFile_acc, zipFile_ori);
			//DELETE compressed temp CSV file
			if(zipFile_acc.delete()){
				System.out.println(zipFile_acc.getName() + " is deleted!");
			}else{
				System.out.println("Compressed CSV file could not be deleted.");
			}
			if(zipFile_ori.delete()){
				System.out.println(zipFile_ori.getName() + " is deleted!");
			}else{
				System.out.println("Compressed CSV file could not be deleted.");
			}

			mp.release(); 
			View view = (View)this.findViewById(R.id.container);
			Context context = view.getContext();
			Intent verbalActivity = new Intent(context,VerbalActivityFree.class);
			//send song as parameter to verbal activity
			verbalActivity.putExtra("song",song_title.getText());//hand over song title
			//verbalActivity.putExtra("username", username);
			startActivityForResult(verbalActivity,1);
		}else
		{
			//enable buttons again after play back
			play_button.setEnabled(false);
			stop_button.setEnabled(false);
			record_button.setEnabled(true);	
			try {
				//prepare player for new play back
				mp.stop();
			} catch (IllegalStateException e) {
				e.printStackTrace();
			}
		}
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(resultCode==1){//set result to close APP
			setResult(1);
			finish();
		}
	}
}
