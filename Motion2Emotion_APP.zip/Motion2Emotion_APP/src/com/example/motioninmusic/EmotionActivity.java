package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/

import java.util.Hashtable;

import com.example.gravitytest.R;

import dbaction.DBHandler;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * EmotionActivity captures the perceived emotional quality of the music in the form of the GEMS-9.
 * 
 * The corresponding view is called activity_emotion. The data is transferred to the central DBHandler instance in order to save it in the sqlite database of the device.
 *  
 *
 */
public class EmotionActivity extends Activity implements OnClickListener {

	private RelativeLayout container;
	//Geneva Emotion Music Scales
	protected static String[] GEMS = {"Verwunderung", "Transzendenz", "Energie", "Zärtlichkeit", "Nostalgie", "Friedlichkeit", "Freude", "Traurigkeit", "Anspannung"};
	private Button save_button; //button proceeding to BackgroundSongActivity
	private TextView song_title; //title and name of artist
	private String username;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_emotion);
		container = (RelativeLayout)this.findViewById(R.id.container);
		song_title = (TextView)this.findViewById(R.id.title_song_emotion);
		//get parameters from previous view
		Intent intent = this.getIntent();
		username = intent.getStringExtra("username");
		String song = intent.getStringExtra("song");
		song_title.setText(song);
		int lastID = song_title.getId(); //get layout element ID in order to add next element underneath
		//add GEMS-9 to layout
		for(String emotion : GEMS)
		{
			lastID = this.addNewEmotion(emotion, lastID);
		}
		save_button = new Button(this.getApplicationContext());
		save_button.setText("weiter");
		RelativeLayout.LayoutParams save_layout_params= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
		// add layout parameter, only if it is not the first emotion to be added
		save_layout_params.addRule(RelativeLayout.BELOW, lastID);
		save_layout_params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		save_button.setId(++lastID);
		container.addView(save_button,save_layout_params);	
		save_button.setOnClickListener(this);
	}

	/**
	 * Pressed when participant continues and leaves the EmotionActivity. 
	 * It reads in all GEMS values and passes them to the central DBHandler instance that saves them on the device's local sqlite db.
	 */
	public void onClick(View view)
	{
		Hashtable<String,Integer> GEMS_values = new Hashtable<String,Integer>();
		int numberOfEmotions = this.container.getChildCount();
		for(int i=0;i<numberOfEmotions;i++)
		{	//if child is a slider (seekbar)
			if(this.container.getChildAt(i) instanceof SeekBar)
			{
				SeekBar currentEmotionBar = (SeekBar)this.container.getChildAt(i);
				int emotion_value = currentEmotionBar.getProgress();
				TextView emotion_headline = (TextView)this.container.getChildAt(i-2);
				String emotion = emotion_headline.getText().toString();
				GEMS_values.put(emotion, emotion_value);
			}
		}
		//save Emotion in database
		DBHandler dbHandler = DBHandler.getInstance(this);
		dbHandler.saveGEMSEmotions(GEMS_values,song_title.getText().toString());

		Intent backgroundsongactivity = new Intent(this,BackgroundSongActivity.class);
		//send song as parameter to verbal activity
		backgroundsongactivity.putExtra("sample_name",song_title.getText());//hand over song title
		backgroundsongactivity.putExtra("username", username);
		startActivityForResult(backgroundsongactivity,1);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    if(resultCode==1){//set result codes to finish and close APP
	    	setResult(1);
	        finish();
	    }
	}

/**
 * AddNewEmotion adds another emotional quality (of the GEMS-9) to the view including headline of the emotion, 
 * its descriptive tags and a slider, as well as descriptions for the min and max positions of the slider.
 * 
 * @param emotion_name name of the emotion to be added (headline)
 * @param lastID view ID of the previous element in order to align it underneath
 * @return view ID of the last added layout element in order to know where to align the next emotion
 */
	private int addNewEmotion(String emotion_name, int lastID)
	{
		Context context = this.getApplicationContext();
		//******** Emotion Headline ****************
		TextView headline = new TextView(context);
		headline.setText(emotion_name);
		headline.setTextColor(Color.parseColor("#FF4400"));
		headline.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
		RelativeLayout.LayoutParams headline_layout_params= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
		// add layout parameter, only if it is not the first emotion to be added
		headline_layout_params.setMargins(5, 15, 5, 0);		
		headline_layout_params.addRule(RelativeLayout.BELOW, lastID);
		headline.setId(++lastID);
		container.addView(headline, headline_layout_params);
		//******** Emotion descriptions **********
		TextView description = new TextView(context);
		switch (emotion_name) {
		case "Transzendenz":
			description.setText(R.string.Transzendenz_tags);
			break;
		case "Traurigkeit":
			description.setText(R.string.Traurigkeit_tags);
			break;
		case "Freude":
			description.setText(R.string.Freude_tags);
			break;
		case "Anspannung":
			description.setText(R.string.Anspannung_tags);
			break;
		case "Friedlichkeit":
			description.setText(R.string.Friedlichkeit_tags);
			break;
		case "Zärtlichkeit":
			description.setText(R.string.Zärtlichkeit_tags);
			break;
		case "Verwunderung":
			description.setText(R.string.Verwunderung_tags);
			break;
		case "Energie":
			description.setText(R.string.Energie_tags);
			break;
		case "Nostalgie":
			description.setText(R.string.Nostalgie_tags);
			break;
		}
		RelativeLayout.LayoutParams description_layout_params= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
		description_layout_params.addRule(RelativeLayout.BELOW, headline.getId());
		description.setId(++lastID);
		description.setTextColor(Color.parseColor("#111111"));
		description.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
		description_layout_params.setMargins(5, 0, 5, 5);
		container.addView(description, description_layout_params);

		//******** Emotion Slider *******************
		SeekBar slider = new SeekBar(context);
		RelativeLayout.LayoutParams slider_layout_params= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
		slider_layout_params.addRule(RelativeLayout.BELOW, description.getId());
		slider_layout_params.setMargins(5, 0, 5, 0);
		slider.setId(++lastID);

		container.addView(slider, slider_layout_params);

		//*************** min text *************
		TextView min = new TextView(context);
		RelativeLayout.LayoutParams min_layout_params= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
		min_layout_params.addRule(RelativeLayout.BELOW, slider.getId());
		min_layout_params.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		min.setLayoutParams(min_layout_params);
		min.setText("gar nicht");
		min.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
		min.setId(++lastID);
		min_layout_params.setMargins(5, 0, 5, 5);
		min.setTextColor(Color.parseColor("#0000FF"));
		container.addView(min);

		//************** max text ****************
		TextView max = new TextView(context);
		RelativeLayout.LayoutParams max_layout_params= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
		max_layout_params.addRule(RelativeLayout.BELOW, slider.getId());
		max_layout_params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		max.setLayoutParams(max_layout_params);
		max_layout_params.setMargins(5, 0, 5, 5);
		max.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
		max.setTextColor(Color.parseColor("#0000FF"));
		max.setText("sehr stark");
		max.setId(++lastID);

		container.addView(max);
		return lastID;
	}

	@Override
	public void onBackPressed() {
		//omits going back to previous activity, for reasons of comparability
	}

}
