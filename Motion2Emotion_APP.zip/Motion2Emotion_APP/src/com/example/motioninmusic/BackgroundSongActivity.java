package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/

import com.example.gravitytest.R;

import dbaction.DBHandler;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.SeekBar;
/**
 * BackgroundSongActivity captures background information about how suitable the participant 
 * assessed the possibility to express the listening experience via motion and words, 
 * how much the person liked the music and about how well the person knew the piece already.
 * 
 * The corresponding View is activity_background_song.
 * 
 * The data is transferred to the central DBHandler instance in order to save it in the sqlite database of the device.
 *
 */
public class BackgroundSongActivity extends Activity {
	
	private Button next_button; //button pressed to continue to the list of samples at the beginning
	private Button quit_button; //button pressed after last piece to finish the experiment
	private Context context;
	private String username;
	private String sample_name; //title and artist of the music
	private SeekBar suitability_Embodied; //how suitable is motion to describe the experience?
	private SeekBar suitability_Verbal; //how suitable are the verbal possibilities to describe the experience?
	private SeekBar known; //how well did the person know the music in advance?
	private SeekBar like; //how much did the person like the music?
	private DBHandler dbHandler; //central db instance

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		//initialize view
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_background_song);
		suitability_Embodied = (SeekBar)this.findViewById(R.id.seekBar_motion_suited);
		suitability_Verbal = (SeekBar)this.findViewById(R.id.seekBar_verbal_suited);
		known = (SeekBar)this.findViewById(R.id.seekBar_known);
		like = (SeekBar)this.findViewById(R.id.seekBar_like);
		//receive parameters from preceeding view
		Intent intent = getIntent();
		username = intent.getStringExtra("username");
		sample_name = intent.getStringExtra("sample_name");
		// get db instance
		dbHandler = DBHandler.getInstance(this);
		this.next_button = (Button)this.findViewById(R.id.button_next_sample);
		this.quit_button = (Button)this.findViewById(R.id.button_quit);
		//if all samples have been assessed, redirect participant to finishing the experiment
		if (dbHandler.turn_counter==dbHandler.songs.length)
		{
			this.quit_button.setEnabled(true);
			this.next_button.setEnabled(false);
		}
		else//else participant is redirected to the beginning to choose the next sample
			this.quit_button.setEnabled(false);
		//add button listeners
		this.quit_button.setOnClickListener(new OnClickListener(){
			public void onClick(View view)
			{
				context = view.getContext();
				Intent i = new Intent(context, SettingActivity.class);  
				i.putExtra("username", username);
				i.putExtra("sample_name", sample_name);
				dbHandler.saveBackgroundSample(suitability_Embodied.getProgress(), suitability_Verbal.getProgress(), like.getProgress(), known.getProgress(), sample_name, dbHandler.turn_counter);
				startActivityForResult(i,1);
			}
		});
		this.next_button.setOnClickListener(new OnClickListener(){
			public void onClick(View view)
			{
				context = view.getContext();
				Intent i = new Intent(context, SampleListActivity.class);  
				i.putExtra("username", username);
				dbHandler.saveBackgroundSample(suitability_Embodied.getProgress(), suitability_Verbal.getProgress(), like.getProgress(), known.getProgress(), sample_name, dbHandler.turn_counter);
				startActivityForResult(i,1);
			}
		});

	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    if(resultCode==1){//set results to close APP
	    	setResult(1);
	        finish();
	    }
	}
	
	@Override
	public void onBackPressed() {
		//omits going back to previous activity, for reasons of comparability
	}
}
