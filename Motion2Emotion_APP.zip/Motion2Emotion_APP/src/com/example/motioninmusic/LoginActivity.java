package com.example.motioninmusic;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.example.gravitytest.R;

import dbaction.DBHandler;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * LoginActivity handles the login requests.
 * 
 * The corresponding view is activity_login.
 *
 */
public class LoginActivity extends Activity {

	private EditText username;
	private EditText password;	
	private	Button login_button;
	private DBHandler dbHandler;
	private Context context;
	private TextView error_message;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		dbHandler = DBHandler.getInstance(this);
		context = this;
		error_message = (TextView)this.findViewById(R.id.textView_error);//message to be displayed when login is incorrect
		username = (EditText)findViewById(R.id.editText_username);
		password = (EditText)findViewById(R.id.editText_password);
		login_button = (Button)findViewById(R.id.button_login);//method login is assigned to button in layout
	}

	/**
	 * login is called when login button has been pressed. It sends a login request to the AsynTask CheckAccount.
	 * 
	 * @param view from which method has been called
	 */
	public void login(View view){
		CheckLogin(username.getText().toString(), password.getText().toString());
	}

	/**
	 * CheckAccount checks if the indicated username and password exist on the central server's MySQL 'Participant' table.
	 * It username and password exist, the participant is redirected to SampleListActivity where the experiment starts 
	 * and all following database requests will be handled via this account.
	 *
	 */
	private class CheckAccount extends AsyncTask<String, Void, Integer> {
		private Dialog loadProgress;

		@Override
		protected Integer doInBackground(String... params) {
			Connection dbConnection = null;
			PreparedStatement preparedStatement = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				dbConnection = DriverManager.getConnection(dbHandler.getMysqlUrl(), dbHandler.getSuperUser(), dbHandler.getSuperUserPassword());
				
				Statement statement = dbConnection.createStatement();
				statement.executeQuery("USE MusicEmotionDB");
				preparedStatement = dbConnection.prepareStatement("Select username from Participant where username = ? ;");
				preparedStatement.setString(1, params[0]);
				ResultSet result = preparedStatement.executeQuery();
				if(result.next())//true if username exists
				{
					//check if password is correct as well
					preparedStatement = dbConnection.prepareStatement("Select * from Participant where username=? AND password=?;");
					preparedStatement.setString(1, params[0]); //set username parameter
					preparedStatement.setString(2, params[1]); //set password parameter
					ResultSet result_password = preparedStatement.executeQuery();
					if(result_password.next())//true if password correct
						return Integer.valueOf(0);
					else
						return Integer.valueOf(2);			
				}else
					return Integer.valueOf(1);	
			}
			catch(Exception e) {
				e.printStackTrace();
				return Integer.valueOf(1);
			}
			finally
			{
				try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		@Override
		protected void onPreExecute()
		{
			loadProgress = ProgressDialog.show(LoginActivity.this, "Anmelden","Ihre Anmeldedaten werden überprüft.", true);             
		}; 

		protected void onPostExecute(Integer result) {
			loadProgress.dismiss();
			switch(result.intValue())
			{
			case 0: {
				dbHandler.setUSERNAME(username.getText().toString());
				dbHandler.setUSER_PASSWORD(password.getText().toString());	
				dbHandler.createNewParticipant(dbHandler.getUSERNAME(), dbHandler.getUSER_PASSWORD());
				Intent listAct = new Intent(context,SampleListActivity.class);
				//send parameter to sample list activity
				listAct.putExtra("username",username.getText().toString());
				listAct.putExtra("password",password.getText().toString());
				startActivityForResult(listAct,1);break;}//grant access, username and password are correct
			//username does not exist
			case 1: error_message.setText("Der Benutzer_innenname ist nicht vergeben. Haben Sie sich verschrieben?");error_message.setVisibility(1);break;
			case 2: error_message.setText("Das Passwort ist nicht korrekt. Haben Sie sich verschrieben?");break;
			default: error_message.setText("Die Logindaten sind nicht korrekt. Haben Sie sich verschrieben?");break;
			}
		}	
	}


	protected void CheckLogin(String username, String password)
	{
		CheckAccount task = new CheckAccount();
		task.execute(username, password);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(resultCode==1){//set result to close APP
			finish();
			System.exit(0);
		}
	}
}
