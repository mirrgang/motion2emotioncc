package dbaction;

/*  This file is part of Motion2Emotion.

    Motion2Emotion is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Motion2Emotion is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Motion2Emotion.  If not, see <http://www.gnu.org/licenses/>

    @author Melanie Irrgang
*/


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

/**
 * DBHandler takes care of the communication between APP and local SQLiteDatabase.
 * It saves data to and retrieves data from the local SQLiteDB.
 *
 */
public class DBHandler extends SQLiteOpenHelper {

	private static final int DATABASE_VERSION = 1;
	private static final String DATABASE_NAME = "MusicEmotionDB.db";
	private Context context;
	private boolean isCreated = false; //takes care of the states, avoids database to be reinitialized during runtime.
	private ArrayList<Integer> motion_IDs; //remembers ids of database entries, such that setting id can be added to the table entries in the aftermath
	private ArrayList<Integer> emotion_IDs; //remembers ids of database entries, such that setting id can be added to the table entries in the aftermath
	private ArrayList<Integer> verbalDescription_IDs; //remembers ids of database entries, such that setting id can be added to the table entries in the aftermath
	private Hashtable<Integer,ArrayList<Integer>> tag_IDs; //remembers ids of tags to add setting id to Sample_has_Verbal_Tag in the aftermath
	private final String USER = ""; //TODO: Enter super user name
	private final String PASSWORD = ""; //TODO: super user password
	private String USERNAME = null;	//user name
	private String USER_PASSWORD = null;	//user password
	private static final String MYSQL_URL = ""; //TODO: Enter your MySQL connection HERE
	private static DBHandler   _instance;
	public static boolean isFirst = true;
	public static String[] songs = null;
	public static boolean[] selected_positions = null;
	public static int turn_counter = 0;

	/** Apply Singleton Pattern to share database among Activities.
	 * 
	 * @param context APP context
	 * @return DBHandler instance
	 */
	public static DBHandler getInstance(Context context)
	{
		if (_instance == null)
		{
			_instance = new DBHandler(context.getApplicationContext());
		}
		return _instance;
	}

	/**
	 * Create database.
	 * 
	 * @param context APP context
	 */
	private DBHandler(Context context) {
		//create DB if does not exist already
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		this.context = context;
		//call to make sure database is created,i.e. onCreate is called, no good style but a workaround
		this.onCreate(this.getWritableDatabase());
	}

	/** 
	 * Set user's name.
	 * @param uSERNAME user name
	 */
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}

	/**
	 * Set user's password.
	 * @param uSER_PASSWORD user password
	 */
	public void setUSER_PASSWORD(String uSER_PASSWORD) {
		USER_PASSWORD = uSER_PASSWORD;
	}

	/**
	 * Get connection string to MySQL-database on central server.
	 * @return connection string
	 */
	public final String getMysqlUrl() {
		return MYSQL_URL;
	}

	/**
	 * Get user's name.
	 * @return user name
	 */
	public String getUSERNAME() {
		return USERNAME;
	}

	/**
	 * Get password of user account.
	 * @return user password
	 */
	public String getUSER_PASSWORD() {
		return USER_PASSWORD;
	}

	/**
	 * Get super user name. Super user is used to open connection in order to check if indicated user exists.
	 * @return super user name
	 */
	public final String getSuperUser()
	{
		return this.USER;
	}

	/**
	 * Get super user password.
	 * @return super user password
	 */
	public final String getSuperUserPassword()
	{
		return this.PASSWORD;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {

		if(!isCreated)
		{
			//##### CREATE Database SCHEMA IF DOES NOT EXIST ################
			try {
				//drop DB first, if exists
				DbUtils.executeSqlScript(this.context, db, "MusicEmotionDBDrop.sql");
				//create DB
				DbUtils.executeSqlScript(this.context, db, "MusicEmotionDB.sql");
				this.motion_IDs = new ArrayList<Integer>();//remember IDs for adding Setting_ID in the aftermath
				this.emotion_IDs = new ArrayList<Integer>();
				this.verbalDescription_IDs = new ArrayList<Integer>();
				this.tag_IDs = new Hashtable<Integer,ArrayList<Integer>>();
				isCreated = true;
			} catch (IOException e) {
				// Script could not be executed
				System.err.println("SQL script could not be executed.");
				e.printStackTrace();
			}//####################################################
		}
	}

	/**
	 * Gets the titles of the samples from the database.
	 * @return String array of song titles
	 */
	public String[] getSongTitles()
	{
		SQLiteDatabase db = null;
		try
		{
			db = this.getReadableDatabase();
			Cursor c = db.rawQuery("SELECT title FROM Sample;", null);
			String[] titles = null;
			if(c.moveToFirst())
			{
				int N = c.getCount();
				titles = new String[N];
				for(int i=0;i<N;i++)
				{
					titles[i] = c.getString(0);
					if(!c.isAfterLast())
						c.moveToNext();
				}
			}
			return titles;
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}finally{
			db.close();
		}
	}

	/**
	 * Get all content from selected table and return it as JSON.
	 * 
	 * @see cursorToString
	 * @param table_name name of table to be selected
	 * @return table content as JSON String
	 */
	public String getTable(String table_name)
	{
		SQLiteDatabase db = null;
		try
		{
			db = this.getReadableDatabase();
			Cursor c = db.rawQuery("SELECT * FROM "+table_name, null);
			String json_content = cursorToString(c);
			return json_content;
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}finally{
			db.close();
		}
	}

	/**
	 * Transforms a ResultSet cursor into JSON.
	 * 
	 * @param crs cursor from select query
	 * @return JSON Formatted table content
	 * @throws UnsupportedEncodingException
	 */
	private String cursorToString(Cursor crs) throws UnsupportedEncodingException {
		JSONArray arr = new JSONArray();
		crs.moveToFirst();
		while (!crs.isAfterLast()) {
			int nColumns = crs.getColumnCount();
			JSONObject row = new JSONObject();
			for (int i = 0 ; i < nColumns ; i++) {
				String colName = crs.getColumnName(i);
				if (colName != null) {
					String val = "";
					try {
						switch (crs.getType(i)) {
						case Cursor.FIELD_TYPE_BLOB   : row.put(colName, new String(crs.getBlob(i), "ISO-8859-1")); break;
						case Cursor.FIELD_TYPE_FLOAT  : row.put(colName, crs.getDouble(i))         ; break;
						case Cursor.FIELD_TYPE_INTEGER: row.put(colName, crs.getLong(i))           ; break;
						case Cursor.FIELD_TYPE_NULL   : row.put(colName, null)                     ; break;
						case Cursor.FIELD_TYPE_STRING : row.put(colName, crs.getString(i))         ; break;
						}
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
			}
			arr.put(row);
			if (!crs.moveToNext())
				break;
		}
		return arr.toString();
	}

	/**
	 * Save Setting parameters in device's SQLiteDB. It also sets the Setting_ID for the other tables.
	 * 
	 * @param mood mood during experiment
	 * @param speakers kind of speakers used during experiment
	 * @param comfort how comfortable participants felt during experiment and its setting
	 * @param company if and which other people had been present during the experiment
	 * @param location place experiment had been conducted
	 * @param device producer of device and model
	 * @return true if setting parameters are successfully saved
	 */
	public boolean saveSetting(String mood, String speakers, String comfort, String company, String location , String device)
	{
		String username = this.getUSERNAME();
		try
		{
			SQLiteDatabase db = this.getWritableDatabase();

			//get participant ID from PARTICIPANT
			int participant_id = -1;
			Cursor d = db.rawQuery("SELECT * FROM Participant WHERE username = ?", new String[] {username});
			d.moveToFirst();
			participant_id = d.getInt(d.getColumnIndex("ID"));

			ContentValues values = new ContentValues();

			if(mood!=null && mood!="")//if user selected a mood, mood is not empty
			{
				values.put("mood", mood);
			}

			if(speakers!=null && speakers!="")//if user selected a mood, mood is not empty
			{
				values.put("speakers", speakers);
			}

			if(comfort!=null && comfort!="")
			{
				values.put("comfortable", comfort);
			}

			if(device!=null && device!="")
			{
				values.put("device", device);
			}

			if(location!=null && location!="")
			{
				values.put("location", location);
			}

			if(company!=null && company!="")
			{
				values.put("company", company);
			}
			int setting_id = (int)db.insert("BackgroundSetting", null, values);
			//########### SAVE SETTING ID in EMOTION, MOTION, VERBALDESCRIPTION, VERBALTAGS ######## 
			//save setting in MOTION
			ContentValues contentvaluesmotion = new ContentValues();
			contentvaluesmotion.put("Setting_ID", setting_id);
			for(int motion_id: this.motion_IDs)
			{
				db.update("Motion", contentvaluesmotion, "ID = "+motion_id, null);
			}
			
			ContentValues contentvalues_emotion = new ContentValues();
			contentvalues_emotion.put("Setting_ID", setting_id);
			for(int emotion_id: this.emotion_IDs)
			{
				db.update("Emotion", contentvalues_emotion, " ID = "+emotion_id, null);
			}
			
			ContentValues contentvalues_verbalDescription = new ContentValues();
			contentvalues_verbalDescription.put("Setting_ID", setting_id);
			for(int verbal_id: this.verbalDescription_IDs)
			{
				db.update("VerbalDescription", contentvalues_verbalDescription,  "ID = "+verbal_id, null);
			}
			for(int sample_id: this.tag_IDs.keySet())
			{
				for(int verbalTagID: this.tag_IDs.get(sample_id))
				{
					ContentValues contentvalues_verbalTags = new ContentValues();
					contentvalues_verbalTags.put("Setting_ID", setting_id);
					db.update("Sample_has_VerbalTags", contentvalues_verbalTags, "VerbalTag_ID = " + verbalTagID +" AND Sample_ID = " + sample_id + " AND Participant_ID = " + participant_id, null);
				}
			}
			this.tag_IDs.clear();
			this.emotion_IDs.clear();
			this.motion_IDs.clear();
			this.verbalDescription_IDs.clear();
			db.close(); // Closing database connection
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Get username from SQLiteDB given its ID.
	 * @param id column id to retrieve user name from
	 * @return user name
	 */
	public String getUsername(int id)
	{
		SQLiteDatabase db = null;
		try
		{
			db = this.getReadableDatabase();			
			//get user name from PARTICIPANT
			Cursor c = db.rawQuery("SELECT username FROM Participant WHERE ID = ?", new String[] {new Integer(id).toString()});
			c.moveToFirst();
			String username = c.getString(c.getColumnIndex("username"));
			return username;
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}finally{
			db.close();
		}
	}

	/**
	 * TEST DB Connection.
	 * @param db
	 */
	private void openDatabase(SQLiteDatabase db) {
		try {
			db = SQLiteDatabase.openDatabase("/data/data/com.pack.store/databases/MusicEmotionDB.db",
					null, SQLiteDatabase.CREATE_IF_NECESSARY);
			//Toast.makeText(this, "DB was opened!", 1).show();
		} catch (SQLiteException e) {
			Toast.makeText(this.context, e.getMessage(), 1).show();
		}
	}

	/**
	 * Get name of tag given its id.
	 * 
	 * @param tag_id id of column to retrieve tag name from
	 * @return tag value
	 */
	public String getTagName(int tag_id)
	{
		SQLiteDatabase db = null;
		try
		{
			db = this.getReadableDatabase();			
			//get tag name from PARTICIPANT
			Cursor c = db.rawQuery("SELECT tag FROM VerbalTag WHERE ID = ?", new String[] {new Integer(tag_id).toString()});
			c.moveToFirst();
			String tag_name = c.getString(c.getColumnIndex("tag"));
			return tag_name;
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}finally{
			db.close();
		}
	}

	/**
	 * Save background parameters concerning the sample.
	 *  
	 * @param suitability_Embodied how suitable embodied expression was
	 * @param suitability_Verbal how suitable verbal expression was
	 * @param like liking of the sample
	 * @param known how known the sample is to participant
	 * @param sample name of sample
	 */
	public void saveBackgroundSample(int suitability_Embodied, int suitability_Verbal, int like, int known, String sample, int order_)
	{
		try{
			SQLiteDatabase db = this.getWritableDatabase();
			//get current Date
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			Date date = new Date();

			//get sample ID from SAMPLE
			int sample_id = -1;
			Cursor c = db.rawQuery("SELECT * FROM Sample WHERE title = ?", new String[] {sample});
			c.moveToFirst();
			sample_id = c.getInt(c.getColumnIndex("ID"));

			//get participant ID from PARTICIPANT
			int participant_id = -1;
			Cursor d = db.rawQuery("SELECT * FROM Participant WHERE username = ?", new String[] {this.getUSERNAME()});
			d.moveToFirst();
			participant_id = d.getInt(d.getColumnIndex("ID"));

			ContentValues values = new ContentValues();
			values.put("Participant_ID", participant_id);
			values.put("Sample_ID", sample_id);
			values.put("liking", like);
			values.put("known", known);
			values.put("order_", order_);
			values.put("suitability_embodied", suitability_Embodied);
			values.put("suitability_verbal", suitability_Verbal);
			values.put("timeStamp", dateFormat.format(date));
			db.insert("BackgroundSample", null, values);
			db.close(); // Closing database connection
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Save verbal tags on local SQLiteDB.
	 * 
	 * @param tags user annotations
	 * @param sample_name name of sample
	 * @return true if saving was successful
	 */
	public boolean saveVerbalTags(String[] tags, String sample_name)
	{
		try
		{
			//TODO check for case, define rule
			SQLiteDatabase db = this.getWritableDatabase();
			//get current Date
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			Date date = new Date();

			//get sample ID from SAMPLE
			int sample_id = -1;
			Cursor c = db.rawQuery("SELECT * FROM Sample WHERE title = ?", new String[] {sample_name});
			c.moveToFirst();
			sample_id = c.getInt(c.getColumnIndex("ID"));

			//get participant ID from PARTICIPANT
			int participant_id = -1;
			Cursor d = db.rawQuery("SELECT * FROM Participant WHERE username = ?", new String[] {this.getUSERNAME()});
			d.moveToFirst();
			participant_id = d.getInt(d.getColumnIndex("ID"));

			ArrayList<Integer> ids = new ArrayList<Integer>();
			
			for(String tag: tags)
			{
				//get participant ID from PARTICIPANT
				int tag_id = -1;
				Cursor e = db.rawQuery("SELECT * FROM VerbalTag WHERE tag = ?", new String[] {tag});
				e.moveToFirst();
				if(e.getCount()>0)//if tag exists in db
				{
					tag_id = e.getInt(e.getColumnIndex("ID"));
				}
				else
				{
					//create new entry in VerbalTags
					ContentValues tagValues = new ContentValues();
					tagValues.put("tag", tag);
					//and remember ID					
					tag_id = (int)db.insert("VerbalTag", null, tagValues);

				}
				ContentValues values = new ContentValues();
				values.put("Participant_ID", participant_id);
				values.put("Sample_ID", sample_id);
				values.put("VerbalTag_ID", tag_id);
				values.put("timeStamp", dateFormat.format(date));
				db.insert("Sample_has_VerbalTags", null, values);
				ids.add(tag_id);
			}
			this.tag_IDs.put(sample_id, ids);
			db.close(); // Closing database connection
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Save GEMS Emotions on local SQLiteDB.
	 * 
	 * @param GEMS_values Hashtable containing the values for the GEMS-9 scales.
	 * @param sample_name name of sample
	 * @return true if saving was successful
	 */
	public boolean saveGEMSEmotions(Hashtable<String,Integer> GEMS_values,String sample_name)
	{
		try
		{
			SQLiteDatabase db = this.getWritableDatabase();
			//get current Date
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			Date date = new Date();

			//get sample ID from SAMPLE
			int sample_id = -1;
			Cursor c = db.rawQuery("SELECT * FROM Sample WHERE title = ?", new String[] {sample_name});
			c.moveToFirst();
			sample_id = c.getInt(c.getColumnIndex("ID"));

			//get participant ID from PARTICIPANT
			int participant_id = -1;
			Cursor d = db.rawQuery("SELECT * FROM Participant WHERE username = ?", new String[] {this.getUSERNAME()});
			d.moveToFirst();
			participant_id = d.getInt(d.getColumnIndex("ID"));

			//insert new entry into Emotion
			ContentValues GEMSValues = new ContentValues();
			GEMSValues.put("tension", GEMS_values.get("Anspannung"));
			GEMSValues.put("joy", GEMS_values.get("Freude"));
			GEMSValues.put("wonder", GEMS_values.get("Verwunderung"));
			GEMSValues.put("sadness", GEMS_values.get("Traurigkeit"));
			GEMSValues.put("transcendence", GEMS_values.get("Transzendenz"));
			GEMSValues.put("energy", GEMS_values.get("Energie"));
			GEMSValues.put("tenderness", GEMS_values.get("Zärtlichkeit"));
			GEMSValues.put("peacefulness", GEMS_values.get("Friedlichkeit"));
			GEMSValues.put("nostalgia", GEMS_values.get("Nostalgie"));
			GEMSValues.put("Participant_ID", participant_id);
			GEMSValues.put("Sample_ID", sample_id);
			GEMSValues.put("timeStamp", dateFormat.format(date));
			int emotion_id = (int)db.insert("Emotion", null, GEMSValues);
			this.emotion_IDs.add(emotion_id);
			db.close(); // Closing database connection
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * Save song titles in local SQLiteDB.
	 * 
	 * @param songs list of songs to be saved in Sample
	 * @return true if songs were successfully saved
	 */
	public boolean saveSongTitles(String[] songs)
	{
		try
		{
			SQLiteDatabase db = this.getWritableDatabase();
			for(String song: songs)
			{
				ContentValues values = new ContentValues();
				values.put("title", song);
				try{
					db.insert("Sample", null, values);
				}catch(Exception e)//if song is already in database
				{
					System.out.println("Song title has already been saved.");
				}
			}
			db.close(); // Closing database connection
			return true;
		}catch(Exception e)
		{
			//e.printStackTrace();
			return false;
		}
	}

	/**
	 * Save open verbal description of sample in SQLiteDB.
	 * @param userText verbal description
	 * @param sample_name name of sample
	 * @return true if saved successfully
	 */
	public boolean saveFreeText(String userText, String sample_name){
		try
		{
			SQLiteDatabase db = this.getWritableDatabase();
			ContentValues values = new ContentValues();
			//get current Date
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			Date date = new Date();

			//get sample ID from SAMPLE
			int sample_id = -1;
			Cursor c = db.rawQuery("SELECT * FROM Sample WHERE title = ?", new String[] {sample_name});
			c.moveToFirst();
			sample_id = c.getInt(c.getColumnIndex("ID"));

			//get participant ID from PARTICIPANT
			int participant_id = -1;
			Cursor d = db.rawQuery("SELECT * FROM Participant WHERE username = ?", new String[] {this.getUSERNAME()});
			d.moveToFirst();
			participant_id = d.getInt(d.getColumnIndex("ID"));

			values.put("Participant_ID", participant_id);
			values.put("Sample_ID", sample_id);
			values.put("freePlainText", userText);
			values.put("timeStamp", dateFormat.format(date));
			int verbal_free_id = (int)db.insert("VerbalDescription", null, values);
			this.verbalDescription_IDs.add(verbal_free_id);
			db.close(); // Closing database connection
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

/**
 * Get songs from local assets folder instead of MySQl-database. 
 * 
 * @param context APP context
 * @return list of samples
 */
	public String[] getSongListFromAssets(Context context)
	{
		LinkedList<String> setlist = new LinkedList<String>();
		String[] songs=null; 
		try {
			String[] files = context.getAssets().list("");
			for(String file : files)
			{
				if(file.endsWith(".mp3"))
				{
					setlist.add(file);
				}
			}
			SQLiteDatabase db = this.getWritableDatabase();
			for(String song: setlist)
			{
				ContentValues values = new ContentValues();
				values.put("title", song);
				db.insert("Sample", null, values);
			}
			db.close();
			//copy files to String array
			songs = new String[setlist.size()];
			for(int i=0; i<setlist.size();i++)
			{
				songs[i] = setlist.get(i);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return songs;
	}

	/**
	 * Test if data has been added to db.
	 * 
	 * @param db database
	 * @param TABLE_NAME name of test table
	 */
	private void testDB(SQLiteDatabase db, String TABLE_NAME)
	{
		Cursor c = null;
		c = db.query(TABLE_NAME, null,null, null, null, null, null);

		if(c.getCount()>0) {
			System.out.println(TABLE_NAME + " contain data.");
		}
	}


	/**
	 * Create Participant in local SQLiteDB.
	 * 
	 * @param username name of user
	 * @param password password of user
	 * @return true if successfully created
	 */
	public boolean createNewParticipant(String username, String password)
	{
		try
		{
			//create participant on local sqliteDB
			SQLiteDatabase db = this.getWritableDatabase();
			ContentValues values = new ContentValues();
			values.put("username", username);
			values.put("password", password);
			db.insert("Participant", null, values);
			db.close(); // Closing database connection
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}


	/**
	 * Save zipped motion data as blob on local SQLiteDB.
	 * 
	 * @param sample_name name of sample
	 * @param zippedFile_acc acceleration data
	 * @param zippedFile_ori orientation data
	 */
	public void saveZippedCSV(String sample_name, File zippedFile_acc, File zippedFile_ori)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		//get current Date
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		Date date = new Date();
		//get sample ID from SAMPLE
		int sample_id = -1;
		Cursor c = db.rawQuery("SELECT * FROM Sample WHERE title = ?", new String[] {sample_name});
		c.moveToFirst();
		sample_id = c.getInt(c.getColumnIndex("ID"));

		//get participant ID from PARTICIPANT
		int participant_id = -1;
		Cursor d = db.rawQuery("SELECT * FROM Participant WHERE username = ?", new String[] {this.getUSERNAME()});
		d.moveToFirst();
		participant_id = d.getInt(d.getColumnIndex("ID"));

		//create new entry in MOTION
		this.testDB(db, "Motion");
		byte[] binary_acc = this.getByteArrayFromFile(zippedFile_acc);
		byte[] binary_ori = this.getByteArrayFromFile(zippedFile_ori);

		ContentValues values = new ContentValues();
		values.put("SensorData_Acc", binary_acc); // accelerometer data
		values.put("SensorData_Ori", binary_ori); // orientation data
		values.put("participant_ID", participant_id);
		values.put("sample_ID", sample_id);
		values.put("timeStamp", dateFormat.format(date));
		// Inserting Row
		int motion_id = (int)db.insert("Motion", null, values);
		this.motion_IDs.add(motion_id);
		this.testDB(db, "Motion"); 
		db.close(); // Closing database connection

	}


	/**
	 * Get byte array from file in order to save it as blob.
	 *  
	 * @param file zipped csv file
	 * @return file as byte array
	 */
	private byte[] getByteArrayFromFile(File file){
		byte[] result=null;
		FileInputStream fileInStr=null;
		try{
			fileInStr=new FileInputStream(file);
			long fileSize=file.length();

			if(fileSize>Integer.MAX_VALUE){
				return null;    //file is too large
			}

			if(fileSize>0){
				result=new byte[(int)fileSize];
				fileInStr.read(result);
			}
		}catch(Exception e){
			e.printStackTrace();
		} finally {
			try {
				fileInStr.close();
			} catch (Exception e) {
			}
		}
		return result;
	}


	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {

	}
/**
 * Get the title that belongs to the given sample id.
 * @param sample_id id of sample
 * @return title of sample
 */
	public String getSampleName(int sample_id) {
		SQLiteDatabase db = null;
		try
		{
			db = this.getReadableDatabase();			
			//get user name from PARTICIPANT
			Cursor c = db.rawQuery("SELECT title FROM Sample WHERE ID = ?", new String[] {new Integer(sample_id).toString()});
			c.moveToFirst();
			String title = c.getString(c.getColumnIndex("title"));
			return title;
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}finally{
			db.close();
		}
	}
}
